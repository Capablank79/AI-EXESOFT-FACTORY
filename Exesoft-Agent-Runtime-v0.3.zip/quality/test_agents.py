import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch, MagicMock
from engine.agents import FreeLLMAPIAdapter, ClaudeCodeAdapter, make_prompt
from engine.agent_runtime import AgentRuntime
from engine.runtime import Result

TASK={'agent':'pm','title':'Definir alcance'}
PROJECT={'name':'Exesoft','request':'Crear producto'}
CTX={'workspace':'.','knowledge':[{'kind':'decision','title':'Objetivo','body':'Solo local','source':'operador'}]}

class AgentTests(unittest.TestCase):
    def test_context_prompt(self):
        prompt=make_prompt(TASK,PROJECT,CTX)
        self.assertIn('Solo local',prompt)
        self.assertIn('Definir alcance',prompt)

    def test_no_key_no_network(self):
        with patch.dict(os.environ,{},clear=True),patch('urllib.request.urlopen') as call:
            r=FreeLLMAPIAdapter().execute(TASK,PROJECT,CTX)
            self.assertFalse(r.success)
            call.assert_not_called()

    def test_router_success_mock(self):
        response=MagicMock()
        response.__enter__.return_value=response
        with patch('urllib.request.urlopen',return_value=response) as open_url,patch('json.load',return_value={'choices':[{'message':{'content':'Plan confirmado'}}]}):
            r=FreeLLMAPIAdapter(api_key='test').execute(TASK,PROJECT,CTX)
            self.assertTrue(r.success)
            self.assertIn('Plan confirmado',r.summary)
            self.assertEqual(open_url.call_args.kwargs['timeout'],90)

    def test_claude_missing_env_does_not_spawn(self):
        with tempfile.TemporaryDirectory() as folder,patch.dict(os.environ,{},clear=True),patch('subprocess.run') as run:
            r=ClaudeCodeAdapter().execute(TASK,PROJECT,{'workspace':folder,'knowledge':[]})
            self.assertFalse(r.success)
            run.assert_not_called()

    def test_claude_planning_flags(self):
        with tempfile.TemporaryDirectory() as folder,patch.dict(os.environ,{'ANTHROPIC_AUTH_TOKEN':'test','ANTHROPIC_BASE_URL':'http://127.0.0.1:3001'}),patch('subprocess.run') as run:
            run.return_value=MagicMock(returncode=0,stdout=json.dumps({'result':'Evaluación de arquitectura'}))
            r=ClaudeCodeAdapter().execute(TASK,PROJECT,{'workspace':folder,'knowledge':[]})
            self.assertTrue(r.success)
            argv=run.call_args.args[0]
            self.assertIn('plan',argv)
            self.assertIn('--disallowedTools',argv)
            self.assertFalse(run.call_args.kwargs['shell'])

    def test_agent_runtime_context_from_brain(self):
        class Spy:
            def execute(self,task,project,context):
                self.context=context
                return Result(True,'Plan')
        with tempfile.TemporaryDirectory() as folder:
            spy=Spy()
            runtime=AgentRuntime(folder,{'pm':spy})
            pid=runtime.orchestrator.create_project('Factory','Construir fábrica')
            runtime.orchestrator.plan_skeleton(pid)
            runtime.brain.remember('decision','Definir alcance','Mantener arquitectura local','operador',pid)
            result=runtime.step(pid)
            self.assertEqual(result['state'],'done')
            self.assertTrue(spy.context['knowledge'])
            self.assertIn('local',spy.context['knowledge'][0]['body'])

if __name__=='__main__':unittest.main()
