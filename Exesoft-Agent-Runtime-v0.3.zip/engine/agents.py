"""Agent adapters v0.3: explicit opt-in and no hidden process execution."""
from __future__ import annotations
import json
import os
import subprocess
import urllib.request
import urllib.error
from pathlib import Path
from engine.runtime import Result

ROLES = {'pm','architect','developer','qa','devops'}

def make_prompt(task, project, context):
    notes = context.get('knowledge', [])[:5]
    knowledge = '\n'.join(f"- [{x['kind']}] {x['title']}: {x['body'][:900]} (fuente: {x['source']})" for x in notes)
    return (f"Rol: {task['agent']}. Proyecto: {project['name']}.\n"
            f"Solicitud original: {project['request'][:4000]}\n"
            f"Tarea: {task['title']}\n"
            f"Workspace: {context['workspace']}\n"
            f"Contexto del Brain:\n{knowledge or '(sin antecedentes)'}\n"
            "No reveles credenciales; no hagas despliegues, compras o borrados. "
            "Responde con un resumen preciso y menciona evidencia comprobable si existe.")

class FreeLLMAPIAdapter:
    """Calls the existing local OpenAI-compatible router; text-only; no tool execution."""
    def __init__(self, api_key=None, endpoint='http://127.0.0.1:3001/v1/chat/completions', model='auto', timeout=90):
        self.api_key = api_key
        self.endpoint = endpoint
        self.model = model
        self.timeout = timeout
        if endpoint != 'http://127.0.0.1:3001/v1/chat/completions':
            raise ValueError('Solo se permite el router local configurado')

    def execute(self, task, project, context):
        if task['agent'] not in ROLES: return Result(False,'Agente no autorizado')
        key = self.api_key or os.environ.get('EXESOFT_ROUTER_KEY')
        if not key: return Result(False, 'Falta EXESOFT_ROUTER_KEY; no se envió ninguna solicitud')
        payload = json.dumps({'model':self.model,'messages':[{'role':'user','content':make_prompt(task,project,context)}], 'max_tokens':900}).encode('utf-8')
        req=urllib.request.Request(self.endpoint,data=payload,headers={'Content-Type':'application/json','Authorization':'Bearer '+key},method='POST')
        try:
            with urllib.request.urlopen(req,timeout=self.timeout) as response:
                parsed=json.load(response)
            content=parsed['choices'][0]['message']['content']
            if not isinstance(content,str) or not content.strip(): return Result(False,'Respuesta vacía del modelo')
            return Result(True,content[:12000])
        except (urllib.error.URLError, TimeoutError, ValueError, KeyError, IndexError, TypeError) as exc:
            return Result(False, 'Error FreeLLMAPI: '+type(exc).__name__)

class ClaudeCodeAdapter:
    """Claude Code in read-only planning mode. Never enables edits or shell execution automatically."""
    def __init__(self, executable='claude', timeout=180, max_turns=3):
        self.executable=executable
        self.timeout=timeout
        self.max_turns=max_turns

    def execute(self, task, project, context):
        if task['agent'] not in ROLES: return Result(False,'Agente no autorizado')
        workspace=Path(context['workspace']).resolve()
        if not workspace.is_dir(): return Result(False,'Workspace inexistente')
        env=os.environ.copy()
        if not env.get('ANTHROPIC_AUTH_TOKEN') or env.get('ANTHROPIC_BASE_URL')!='http://127.0.0.1:3001':
            return Result(False,'Se requiere ANTHROPIC_AUTH_TOKEN y ANTHROPIC_BASE_URL local')
        env.pop('ANTHROPIC_API_KEY',None)
        argv=[self.executable,'-p',make_prompt(task,project,context), '--output-format','json',
              '--permission-mode','plan','--max-turns',str(self.max_turns),
              '--disallowedTools','Bash','Edit','Write','NotebookEdit']
        try:
            completed=subprocess.run(argv,cwd=str(workspace),env=env,capture_output=True,text=True,
                                     timeout=self.timeout, shell=False,encoding='utf-8',errors='replace')
        except (OSError,subprocess.TimeoutExpired) as exc:
            return Result(False,'Error Claude Code: '+type(exc).__name__)
        if completed.returncode:
            return Result(False, f'Claude Code terminó con código {completed.returncode}; revisar logs locales')
        try:
            obj=json.loads(completed.stdout)
            message=obj.get('result','')
        except (json.JSONDecodeError,AttributeError):
            return Result(False,'Claude Code no devolvió JSON válido')
        if not isinstance(message,str) or not message.strip():
            return Result(False,'Claude Code devolvió respuesta vacía')
        return Result(True,message[:12000])
