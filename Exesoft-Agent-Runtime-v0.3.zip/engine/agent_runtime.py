"""Incremental integration: brain retrieval + adapter registry without changing v0.2."""
from pathlib import Path
import re
from engine.runtime import Runtime
from engine.agents import ClaudeCodeAdapter, FreeLLMAPIAdapter

class AgentRuntime(Runtime):
    def __init__(self, root, adapters=None):
        if adapters is None:
            # explicit safe defaults: PM and architect via text-only model; developer via read-only Claude
            adapters = {'pm': FreeLLMAPIAdapter(), 'architect': FreeLLMAPIAdapter(),
                        'developer': ClaudeCodeAdapter(), 'qa': FreeLLMAPIAdapter(),
                        'devops': ClaudeCodeAdapter()}
        super().__init__(root,adapters)

    def _dispatch(self, task, project):
        adapter=self.adapters.get(task['agent'])
        if adapter is None:
            return super()._dispatch(task,project)
        workspace=(self.root/'workspaces'/project['id']).resolve()
        workspace.mkdir(parents=True,exist_ok=True)
        # FTS5 escapes user text into token-safe quoted terms; malformed syntax cannot crash runtime.
        terms=re.findall(r'\w+', task['title'],flags=re.UNICODE)[:5]
        knowledge=[]
        if terms:
            try: knowledge=self.brain.recall(' OR '.join('"'+w.replace('"','')+'"' for w in terms),project['id'],limit=5)
            except Exception: knowledge=[]
        return adapter.execute(task,project,{'workspace':str(workspace), 'request':project['request'],
                                             'task_id':task['id'], 'knowledge':knowledge})
