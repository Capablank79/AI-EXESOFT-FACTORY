"""Evidence is produced by trusted local execution, not by LLM claims."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone
from uuid import uuid4


def _inside(root: Path, candidate: Path) -> Path:
    root = root.resolve(strict=True)
    path = candidate.resolve(strict=True)
    if not path.is_relative_to(root):
        raise ValueError('Ruta fuera del workspace autorizado')
    return path


def file_evidence(workspace, relative_path):
    root = Path(workspace).resolve(strict=True)
    path = _inside(root, root / relative_path)
    if not path.is_file():
        raise ValueError('No es un archivo')
    return {'kind':'file','path':str(path.relative_to(root)),
            'sha256':hashlib.sha256(path.read_bytes()).hexdigest(), 'size':path.stat().st_size}


def verify_file(workspace, evidence):
    if evidence.get('kind') != 'file': return False
    try:
        real=file_evidence(workspace, evidence['path'])
        return real == evidence
    except (OSError, ValueError, KeyError, TypeError):
        return False


def run_tests(workspace, *, timeout=90):
    """Runs only unittest discovery from the project's tests/ directory (no model-supplied commands).

    The tests are executable code and MUST be trusted before invoking this function.
    """
    root=Path(workspace).resolve(strict=True)
    tests=_inside(root, root/'tests')
    if not tests.is_dir(): raise ValueError('No existe tests/ en el workspace')
    timeout=max(1,min(int(timeout),300))
    cmd=[sys.executable,'-I','-m','unittest','discover','-s',str(tests),'-p','test_*.py','-v']
    try:
        proc=subprocess.run(cmd,cwd=root,capture_output=True,text=True,errors='replace',
                            timeout=timeout,stdin=subprocess.DEVNULL,
                            env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
        status='passed' if proc.returncode==0 else 'failed'
        output=(proc.stdout+'\n'+proc.stderr)[-24000:]
        code=proc.returncode
    except subprocess.TimeoutExpired as exc:
        status='timeout'; code=None
        def decode(s): return s.decode(errors='replace') if isinstance(s,bytes) else (s or '')
        output=(decode(exc.stdout)+'\n'+decode(exc.stderr))[-24000:]
    artifact={'schema':'exesoft.quality.test.v1','id':uuid4().hex,
              'kind':'test','status':status,'returncode':code,
              'command':'python -I -m unittest discover -s tests -p test_*.py -v',
              'output':output,'output_sha256':hashlib.sha256(output.encode()).hexdigest(),
              'timestamp':datetime.now(timezone.utc).isoformat()}
    return artifact


def record_evidence(workspace, artifact):
    root=Path(workspace).resolve(strict=True)
    evidence_dir=root/'.exesoft'/'evidence'
    evidence_dir.mkdir(parents=True,exist_ok=True)
    if artifact.get('schema')!='exesoft.quality.test.v1': raise ValueError('Esquema desconocido')
    target=evidence_dir/(artifact['id']+'.json')
    with target.open('x',encoding='utf-8') as f:
        json.dump(artifact,f,ensure_ascii=False,indent=2)
    return str(target.relative_to(root))


def verify_test_evidence(workspace, relative_path):
    root=Path(workspace).resolve(strict=True)
    try:
        p=_inside(root,root/relative_path)
        if p.parent != (root/'.exesoft'/'evidence').resolve(): return False
        data=json.loads(p.read_text(encoding='utf-8'))
        return (data.get('schema')=='exesoft.quality.test.v1' and
                data.get('status')=='passed' and data.get('returncode')==0 and
                isinstance(data.get('output'),str) and
                hashlib.sha256(data['output'].encode()).hexdigest()==data.get('output_sha256'))
    except (ValueError, KeyError, TypeError, OSError, json.JSONDecodeError):
        return False
