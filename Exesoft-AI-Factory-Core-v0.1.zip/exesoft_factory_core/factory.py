"""CLI local para el núcleo Exesoft AI Factory."""
import argparse
import json
from pathlib import Path
from engine.orchestrator import Orchestrator

ROOT=Path(__file__).resolve().parent

def main():
    parser=argparse.ArgumentParser(description='Exesoft AI Factory — núcleo persistente')
    sub=parser.add_subparsers(dest='command',required=True)
    p=sub.add_parser('create');p.add_argument('name');p.add_argument('request')
    p=sub.add_parser('plan');p.add_argument('project_id')
    p=sub.add_parser('status');p.add_argument('project_id')
    p=sub.add_parser('remember');p.add_argument('title');p.add_argument('body');p.add_argument('--source',required=True)
    p=sub.add_parser('recall');p.add_argument('query')
    args=parser.parse_args()
    app=Orchestrator(ROOT)
    if args.command=='create': out={'project_id':app.create_project(args.name,args.request)}
    elif args.command=='plan': out=app.plan_skeleton(args.project_id)
    elif args.command=='status': out={'project':app.brain.get_project(args.project_id),'tasks':app.brain.tasks(args.project_id),'ready':app.ready_tasks(args.project_id)}
    elif args.command=='remember':out={'knowledge_id':app.brain.remember('note',args.title,args.body,args.source)}
    else:out=app.brain.recall(args.query)
    print(json.dumps(out,indent=2,ensure_ascii=False))

if __name__=='__main__': main()
