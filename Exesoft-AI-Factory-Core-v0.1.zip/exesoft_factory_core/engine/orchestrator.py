"""Núcleo de planificación persistente. No llama modelos ni ejecuta comandos todavía."""
from pathlib import Path
from uuid import uuid4
import json
from brain.store import Brain

ROLES=('pm','architect','developer','qa','devops')

class Orchestrator:
    def __init__(self, root):
        self.root=Path(root)
        self.brain=Brain(self.root/'brain'/'brain.db')

    def create_project(self, name, request):
        if not name.strip() or not request.strip():
            raise ValueError('Nombre y solicitud son obligatorios')
        pid=uuid4().hex[:12]
        folder=self.root/'workspaces'/pid
        folder.mkdir(parents=True,exist_ok=False)
        self.brain.add_project(pid,name,request)
        (folder/'request.md').write_text('# '+name+'\n\n'+request+'\n',encoding='utf-8')
        return pid

    def plan_skeleton(self, pid):
        project=self.brain.get_project(pid)
        if not project: raise KeyError(pid)
        if self.brain.tasks(pid):
            raise ValueError('El proyecto ya tiene tareas; no duplicar planificación')
        names=[('Definir alcance y aceptación','pm'),('Definir arquitectura','architect'),
               ('Implementar según alcance','developer'),('Validar mediante pruebas','qa'),
               ('Preparar entrega local','devops')]
        previous=None
        for title,agent in names:
            tid=uuid4().hex[:12]
            self.brain.add_task(tid,pid,title,agent,[previous] if previous else [])
            previous=tid
        self.brain.set_project_status(pid,'planned')
        return self.brain.tasks(pid)

    def ready_tasks(self,pid):
        tasks=self.brain.tasks(pid)
        done={t['id'] for t in tasks if t['status']=='done'}
        return [t for t in tasks if t['status']=='pending' and t['attempts']<t['max_attempts']
                and all(dep in done for dep in json.loads(t['depends_on']))]
